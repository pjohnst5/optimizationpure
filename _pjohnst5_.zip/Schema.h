#pragma once
#include <vector>
#include <iostream>

using namespace std;

class Schema: public vector<string>
{
public:
  Schema() {}

private:
  
};
