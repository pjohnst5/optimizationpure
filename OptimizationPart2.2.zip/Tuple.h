#pragma once
#include <vector>
#include <iostream>

using namespace std;

class Tuple: public vector<string>
{
public:
  Tuple() {}
  
private:


};
